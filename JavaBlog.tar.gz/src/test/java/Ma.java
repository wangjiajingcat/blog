import com.blade.kit.UUID;

public class Ma {


    public static void main(String[] args) {
        System.out.println(UUID.UU64());
    }
}
