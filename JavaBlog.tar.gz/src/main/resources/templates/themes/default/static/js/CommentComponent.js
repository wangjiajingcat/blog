class InputComponent extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            author: this.props.author,
            mail: this.props.mail,
            message: this.props.message
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            author: nextProps.author,
            mail: nextProps.mail,
            message: nextProps.message
        })
    }

    render() {
        return (
            <div style={{flexDirection: "column", display: "flex"}}>
                <input style={{
                    width: "50%",
                    margin: 10,
                    padding: 10,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderStyle: "solid",
                    borderColor: "#b1b1b1",
                    fontFamily: "myfont",
                    fontSize: 17,
                    color: "#555555",
                }}
                       placeholder="你的身份"
                       onChange={this.onChange1.bind(this)}
                       value={this.state.author}/>
                <input style={{
                    width: "50%",
                    margin: 10,
                    padding: 10,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderStyle: "solid",
                    borderColor: "#b1b1b1",
                    fontFamily: "myfont",
                    fontSize: 17,
                    color: "#555555",
                }}
                       placeholder="你的邮箱"
                       onChange={this.onChange2.bind(this)}
                       value={this.state.mail}/>
                <textarea style={{
                    alignSelf: "stretch",
                    height: 100,
                    margin: 10,
                    padding: 10,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderStyle: "solid",
                    borderColor: "#b1b1b1",
                    fontFamily: "myfont",
                    fontSize: 17,
                    color: "#555555",
                }}
                          placeholder="说点什么吧"
                          onChange={this.onChange3.bind(this)}
                          value={this.state.message}/>
                <a href="javascript:" onClick={this.onSend.bind(this)}
                   style={{textDecoration: "none", color: "#555555", margin: 15, fontSize: 18}}>提交</a>
            </div>
        )
    }

    onChange1(it) {
        let author = it.target.value;
        this.setState({
            author: author
        })
    }

    onChange2(it) {
        let mail = it.target.value;
        this.setState({
            mail: mail
        })
    }

    onChange3(it) {
        let message = it.target.value;
        this.setState({
            message: message
        })
    }

    onSend() {
        if (this.props.sendData) {
            this.props.sendData(this.state.author, this.state.mail, this.state.message)
        }
    }

}

class CommentListComponent extends React.Component {

    render() {
        return (
            <div style={{marginBottom: 10}}>
                {this.props.commentList.map(this.renderItem.bind(this))}
            </div>
        )
    }

    renderItem(item, index) {
        return <div
            style={{
                borderColor: "#b3b3b3",
                borderRadius: 8,
                borderWidth: 1,
                padding: 10,
                borderStyle: "solid",
                margin: 5
            }}
            key={index}>
            <div style={{margin: 5}}>{item.author}（{item.mail}）</div>
            <div style={{color: "#111"}}>{item.content}</div>
        </div>
    }
}


class CommentComponent extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            author: "",
            mail: "",
            message: "",
            commentList: []
        }
    }


    render() {
        return (
            <div>
                <CommentListComponent commentList={this.state.commentList}/>
                <InputComponent author={this.state.author} mail={this.state.mail} message={this.state.message}
                                sendData={this.sendData.bind(this)}/>
            </div>
        )
    }

    sendData(author, mail, message) {
        if (!author) {
            alert("请输入身份");
            return;
        }
        if (author.length > 50) {
            alert("身份过长");
            return;
        }
        if (!mail) {
            alert("请输入邮箱");
            return;
        }
        let filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(mail)) {
            alert("请输入正确的邮箱");
            return true;
        }
        if (!message) {
            alert("请输入留言");
            return;
        }
        if (message.length < 5 || message.length >= 2000) {
            alert("留言字数在5-2000个字符");
            return;
        }
        console.info("sending " + message)
        let formData = new FormData();
        formData.append("text", message);
        formData.append("author", author);
        formData.append("mail", mail);

        fetch("/sendComment", {
            method: 'POST',
            body: formData
        }).then(function (response) {
            return response.json()
        }).then(function (jsonObj) {
            console.info(jsonObj)
            this.getCommentList()
        }.bind(this));
    }

    componentDidMount() {
        this.getCommentList()
    }

    getCommentList() {
        fetch("/commentsList").then(function (response) {
            return response.json()
        }).then(function (jsonObj) {
            console.info(jsonObj);
            this.setState({
                message: "",
                commentList: jsonObj.list
            })
        }.bind(this));
    }
}


ReactDOM.render(
    <CommentComponent/>,
    document.getElementById("cloud-tie-wrapper")
);