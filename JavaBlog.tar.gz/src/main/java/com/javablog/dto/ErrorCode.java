package com.javablog.dto;

public interface ErrorCode {

    /**
     * 非法请求
     */
    String BAD_REQUEST = "BAD REQUEST";

}
