package com.javablog.dto;

import com.javablog.model.Metas;

public class MetaDto extends Metas {

    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
