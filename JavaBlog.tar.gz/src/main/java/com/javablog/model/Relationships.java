package com.javablog.model;

import com.blade.jdbc.annotation.Table;

import java.io.Serializable;

//
@Table(name = "t_relationships", pk = "mid")
public class Relationships implements Serializable {

    private static final long serialVersionUID = 1L;

    // 内容主键
    private Integer cid;

    // 项目主键
    private Integer mid;

    public Relationships() {
    }

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Integer getMid() {
        return mid;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }


}