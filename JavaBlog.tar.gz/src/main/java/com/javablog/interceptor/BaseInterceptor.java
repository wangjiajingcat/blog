package com.javablog.interceptor;

import com.blade.ioc.annotation.Inject;
import com.blade.kit.IPKit;
import com.blade.kit.StringKit;
import com.blade.kit.UUID;
import com.blade.mvc.annotation.Intercept;
import com.blade.mvc.http.Request;
import com.blade.mvc.http.Response;
import com.blade.mvc.interceptor.Interceptor;
import com.javablog.dto.Types;
import com.javablog.init.BlogConst;
import com.javablog.model.Users;
import com.javablog.service.UsersService;
import com.javablog.utils.MapCache;
import com.javablog.utils.BlogUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Intercept
public class BaseInterceptor implements Interceptor {

    private static final Logger LOGGE = LoggerFactory.getLogger(BaseInterceptor.class);

    @Inject
    private UsersService usersService;

    private MapCache cache = MapCache.single();

    @Override
    public boolean before(Request request, Response response) {

        String uri = request.uri();
        String ip = IPKit.getIpAddrByRequest(request.raw());

        // 禁止该ip访问
        if(BlogConst.BLOCK_IPS.contains(ip)){
            response.text("You have been banned, brother");
            return false;
        }

        LOGGE.info("UserAgent: {}", request.userAgent());
        LOGGE.info("用户访问地址: {}, 来路地址: {}", uri, ip);

        if (!BlogConst.INSTALL && !uri.startsWith("/install")) {
            response.go("/install");
            return false;
        }

        if (BlogConst.INSTALL) {
            Users user = BlogUtils.getLoginUser();
            if (null == user) {
                Integer uid = BlogUtils.getCookieUid(request);
                if (null != uid) {
                    user = usersService.byId(Integer.valueOf(uid));
                    request.session().attribute(BlogConst.LOGIN_SESSION_KEY, user);
                }
            }

            if(uri.startsWith("/admin") && !uri.startsWith("/admin/login")){
                if(null == user){
                    response.go("/admin/login");
                    return false;
                }
                request.attribute("plugin_menus", BlogConst.plugin_menus);
            }
        }
        String method = request.method();
        if(method.equals("GET")){
            String csrf_token = UUID.UU64();
            // 默认存储20分钟
            int timeout = BlogConst.BCONF.getInt("app.csrf-token-timeout", 20) * 60;
            cache.hset(Types.CSRF_TOKEN, csrf_token, uri, timeout);
            request.attribute("_csrf_token", csrf_token);
        }
        return true;
    }


    @Override
    public boolean after(Request request, Response response) {
        String _csrf_token = request.attribute("del_csrf_token");
        if(StringKit.isNotBlank(_csrf_token)){
            // 移除本次token
            cache.hdel(Types.CSRF_TOKEN, _csrf_token);
        }
        return true;
    }

}
