package com.javablog;

import com.javablog.init.BlogLoader;

import static com.blade.Blade.$;

public class Application {

    public static void main(String[] args) throws Exception {
        BlogLoader.init();
        $().start(Application.class);
    }

}