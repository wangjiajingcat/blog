package com.javablog.utils;

public class RewriteUtils {

    public static void rewrite(String suffix){
        try {
        } catch (Exception e){
            e.printStackTrace();
        }
    }

}
