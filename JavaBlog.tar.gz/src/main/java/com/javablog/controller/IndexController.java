package com.javablog.controller;

import com.blade.ioc.annotation.Inject;
import com.blade.jdbc.core.Take;
import com.blade.jdbc.model.Paginator;
import com.blade.kit.IPKit;
import com.blade.kit.PatternKit;
import com.blade.kit.StringKit;
import com.blade.mvc.annotation.*;
import com.blade.mvc.http.HttpMethod;
import com.blade.mvc.http.Request;
import com.blade.mvc.http.Response;
import com.blade.mvc.http.wrapper.Session;
import com.blade.mvc.view.RestResponse;
import com.google.gson.Gson;
import com.javablog.dto.*;
import com.javablog.exception.TipException;
import com.javablog.ext.Commons;
import com.javablog.init.BlogConst;
import com.javablog.model.Comments;
import com.javablog.model.Contents;
import com.javablog.model.Metas;
import com.javablog.service.*;
import com.javablog.utils.BlogUtils;
import com.vdurmont.emoji.EmojiParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

@Controller
public class IndexController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(IndexController.class);

    @Inject
    private ContentsService contentsService;

    @Inject
    private MetasService metasService;

    @Inject
    private CommentsService commentsService;

    @Inject
    private SiteService siteService;

    @Inject
    private OptionsService optionsService;

    /**
     * 首页
     *
     * @return
     */
    @Route(value = "/", method = HttpMethod.GET)
    public String index(Request request, @QueryParam(value = "limit", defaultValue = "12") int limit, Response response) {
        System.out.println(response);
        Map<String, String> options = optionsService.getOptions();
        request.attribute("options", options);
        return this.render("index");
//        response.json(new Object());
//        return this.index(request, 1, limit);
//        String html = "<h1>Hello Blade!</h1>";
//        response.html(html);
    }

    class BlogPage {
        Contents blog;
        int[] navPageNums;
    }

    @Route(value = "/blog")
    public void getBlog(Request request, Response response) {
        int pageNum = request.queryInt("pageNum", 1);
        Take take = new Take(Contents.class).eq("type", Types.ARTICLE).eq("status", Types.PUBLISH).page(pageNum, 1, "created desc");
        Paginator<Contents> articles = contentsService.getArticles(take);

        int[] navPageNums = articles.getNavPageNums();
        List<Contents> list = articles.getList();
        Contents contents = list.get(0);
        BlogPage blogPage = new BlogPage();
        blogPage.blog = contents;
        blogPage.navPageNums = navPageNums;
        response.text(new Gson().toJson(articles));
    }

    @Route(value = "/blogList")
    public void getBlogList(Request request, Response response) {
        Take take = new Take(Contents.class).eq("type", Types.ARTICLE).eq("status", Types.PUBLISH).page(1, Integer.MAX_VALUE, "created desc");
        Paginator<Contents> articles = contentsService.getArticles(take);
        response.text(new Gson().toJson(articles.getList()));
    }

    /**
     * 首页
     *
     * @return
     */
    @Route(value = "/index_back", method = HttpMethod.GET)
    public String index_back(Request request, @QueryParam(value = "limit", defaultValue = "12") int limit) {
        return this.index_back(request, 1, limit);
    }

    /**
     * 自定义页面内容
     */
    @Route(values = {"/:cid", "/:cid.html"}, method = HttpMethod.GET)
    public void pageContent(@PathParam String cid, Request request, Response response) {
        Contents contents = contentsService.getContents(cid);
        if (null == contents) {
//            return this.render_404();
        }
        if (contents.getAllow_comment()) {
            int cp = request.queryInt("cp", 1);
            request.attribute("cp", cp);
        }
        request.attribute("article", contents);
        updateArticleHit(contents.getCid(), contents.getHits());

//        String hh = this.render("page");//自定义

        response.text(new Gson().toJson(contents));
//        if (Types.ARTICLE.equals(contents.getType())) {
//            return this.render("post");//博客
//        }
//        if (Types.PAGE.equals(contents.getType())) {
//            return this.render("page");//自定义
//        }
//        return this.render_404();
    }


    /**
     * 获取当前文章/页面的评论
     */
    @Route(value = "/commentsList")
    public void comments(Response response) {
        Paginator<Comment> comments = siteService.getComments(1, 1, Integer.MAX_VALUE);
        response.text(new Gson().toJson(comments));
    }


//    /**
//     * 自定义页面
//     */
//    @Route(values = {"/:cid", "/:cid.html"}, method = HttpMethod.GET)
//    public String page(@PathParam String cid, Request request) {
//        Contents contents = contentsService.getContents(cid);
//        if (null == contents) {
//            return this.render_404();
//        }
//        if (contents.getAllow_comment()) {
//            int cp = request.queryInt("cp", 1);
//            request.attribute("cp", cp);
//        }
//        request.attribute("article", contents);
//        updateArticleHit(contents.getCid(), contents.getHits());
//        if (Types.ARTICLE.equals(contents.getType())) {
//            return this.render("post");
//        }
//        if (Types.PAGE.equals(contents.getType())) {
//            return this.render("page");
//        }
//        return this.render_404();
//    }

    /**
     * 首页分页
     *
     * @param request
     * @param page
     * @param limit
     * @return
     */
    @Route(values = {"page/:page", "page/:page.html"}, method = HttpMethod.GET)
    public String index(Request request, @PathParam int page, @QueryParam(value = "limit", defaultValue = "12") int limit) {
        page = page < 0 || page > BlogConst.MAX_PAGE ? 1 : page;
        Take take = new Take(Contents.class).eq("type", Types.ARTICLE).eq("status", Types.PUBLISH).page(page, limit, "created desc");
        Paginator<Contents> articles = contentsService.getArticles(take);
        request.attribute("articles", articles);
        if (page > 1) {
            this.title(request, "第" + page + "页");
        }
        request.attribute("is_home", true);
        request.attribute("page_prefix", "/page");
        return this.render("index");
    }


    /**
     * 首页分页
     *
     * @param request
     * @param page
     * @param limit
     * @return
     */
    @Route(values = {"page/:page", "page/:page.html"}, method = HttpMethod.GET)
    public String index_back(Request request, @PathParam int page, @QueryParam(value = "limit", defaultValue = "12") int limit) {
        page = page < 0 || page > BlogConst.MAX_PAGE ? 1 : page;
        Take take = new Take(Contents.class).eq("type", Types.ARTICLE).eq("status", Types.PUBLISH).page(page, limit, "created desc");
        Paginator<Contents> articles = contentsService.getArticles(take);
        request.attribute("articles", articles);
        if (page > 1) {
            this.title(request, "第" + page + "页");
        }
        request.attribute("is_home", true);
        request.attribute("page_prefix", "/page");
        return this.render("index_content");
    }

    /**
     * 文章页
     */
    @Route(values = {"article/:cid", "article/:cid.html"}, method = HttpMethod.GET)
    public String post(Request request, @PathParam String cid) {
        Contents contents = contentsService.getContents(cid);
        if (null == contents || Types.DRAFT.equals(contents.getStatus())) {
            return this.render_404();
        }
        System.out.println(contents);
        request.attribute("article", contents);
        request.attribute("is_post", true);
        if (contents.getAllow_comment()) {
            int cp = request.queryInt("cp", 1);
            request.attribute("cp", cp);
        }
        updateArticleHit(contents.getCid(), contents.getHits());
        return this.render("post");
    }

    private void updateArticleHit(Integer cid, Integer chits) {
        Integer hits = cache.hget(Types.C_ARTICLE_HITS, cid.toString());
        hits = null == hits ? 1 : hits + 1;
        if (hits >= BlogConst.HIT_EXCEED) {
            Contents temp = new Contents();
            temp.setCid(cid);
            temp.setHits(chits + hits);
            contentsService.update(temp);
            cache.hset(Types.C_ARTICLE_HITS, cid.toString(), 1);
        } else {
            cache.hset(Types.C_ARTICLE_HITS, cid.toString(), hits);
        }
    }

    /**
     * 分类页
     *
     * @return
     */
    @Route(values = {"category/:keyword", "category/:keyword.html"}, method = HttpMethod.GET)
    public String categories(Request request, @PathParam String keyword, @QueryParam(value = "limit", defaultValue = "12") int limit) {
        return this.categories(request, keyword, 1, limit);
    }

    @Route(values = {"category/:keyword/:page", "category/:keyword/:page.html"}, method = HttpMethod.GET)
    public String categories(Request request, @PathParam String keyword,
                             @PathParam int page, @QueryParam(value = "limit", defaultValue = "12") int limit) {
        page = page < 0 || page > BlogConst.MAX_PAGE ? 1 : page;
        MetaDto metaDto = metasService.getMeta(Types.CATEGORY, keyword);
        if (null == metaDto) {
            return this.render_404();
        }

        Paginator<Contents> contentsPaginator = contentsService.getArticles(metaDto.getMid(), page, limit);

        request.attribute("articles", contentsPaginator);
        request.attribute("meta", metaDto);
        request.attribute("type", "分类");
        request.attribute("keyword", keyword);
        request.attribute("is_category", true);
        request.attribute("page_prefix", "/category/" + keyword);

        return this.render("page-category");
    }

    /**
     * 标签页
     *
     * @param name
     * @return
     */
    @Route(values = {"tag/:name", "tag/:name.html"}, method = HttpMethod.GET)
    public String tags(Request request, @PathParam String name, @QueryParam(value = "limit", defaultValue = "12") int limit) {
        return this.tags(request, name, 1, limit);
    }

    /**
     * 标签分页
     *
     * @param request
     * @param name
     * @param page
     * @param limit
     * @return
     */
    @Route(values = {"tag/:name/:page", "tag/:name/:page.html"}, method = HttpMethod.GET)
    public String tags(Request request, @PathParam String name, @PathParam int page, @QueryParam(value = "limit", defaultValue = "12") int limit) {

        page = page < 0 || page > BlogConst.MAX_PAGE ? 1 : page;
        MetaDto metaDto = metasService.getMeta(Types.TAG, name);
        if (null == metaDto) {
            return this.render_404();
        }

        Paginator<Contents> contentsPaginator = contentsService.getArticles(metaDto.getMid(), page, limit);
        request.attribute("articles", contentsPaginator);
        request.attribute("meta", metaDto);
        request.attribute("type", "标签");
        request.attribute("keyword", name);
        request.attribute("is_tag", true);
        request.attribute("page_prefix", "/tag/" + name);

        return this.render("page-category");
    }

    /**
     * 搜索页
     *
     * @param keyword
     * @return
     */
    @Route(values = {"search/:keyword", "search/:keyword.html"}, method = HttpMethod.GET)
    public String search(Request request, @PathParam String keyword, @QueryParam(value = "limit", defaultValue = "12") int limit) {
        return this.search(request, keyword, 1, limit);
    }

    @Route(values = {"search", "search.html"})
    public String search(Request request, @QueryParam(value = "limit", defaultValue = "12") int limit) {
        String keyword = request.query("s");
        return this.search(request, keyword, 1, limit);
    }

    @Route(values = {"search/:keyword/:page", "search/:keyword/:page.html"}, method = HttpMethod.GET)
    public String search(Request request, @PathParam String keyword, @PathParam int page, @QueryParam(value = "limit", defaultValue = "12") int limit) {

        page = page < 0 || page > BlogConst.MAX_PAGE ? 1 : page;
        Take take = new Take(Contents.class).eq("type", Types.ARTICLE).eq("status", Types.PUBLISH)
                .like("title", "%" + keyword + "%").page(page, limit, "created desc");

        Paginator<Contents> articles = contentsService.getArticles(take);
        request.attribute("articles", articles);

        request.attribute("type", "搜索");
        request.attribute("keyword", keyword);
        request.attribute("page_prefix", "/search/" + keyword);
        return this.render("page-category");
    }

    /**
     * 归档页
     *
     * @return
     */
    @Route(values = {"archives", "archives.html"}, method = HttpMethod.GET)
    public String archives(Request request) {
        List<Archive> archives = siteService.getArchives();
        request.attribute("archives", archives);
        request.attribute("is_archive", true);
        return this.render("archives");
    }

    /**
     * 友链页
     *
     * @return
     */
    @Route(values = {"links", "links.html"}, method = HttpMethod.GET)
    public String links(Request request) {
        List<Metas> links = metasService.getMetas(Types.LINK);
        request.attribute("links", links);
        return this.render("links");
    }

    /**
     * feed页
     *
     * @return
     */
    @Route(values = {"feed", "feed.xml"}, method = HttpMethod.GET)
    public void feed(Response response) {
        Paginator<Contents> contentsPaginator = contentsService.getArticles(new Take(Contents.class)
                .eq("type", Types.ARTICLE).eq("status", Types.PUBLISH).eq("allow_feed", true).page(1, BlogConst.MAX_POSTS, "created desc"));
        try {
            String xml = BlogUtils.getRssXml(contentsPaginator.getList());
            response.xml(xml);
        } catch (Exception e) {
            LOGGER.error("生成RSS失败", e);
        }
    }

    /**
     * 注销
     *
     * @param session
     * @param response
     */
    @Route("logout")
    public void logout(Session session, Response response) {
        BlogUtils.logout(session, response);
    }


    /**
     * 评论操作
     */
    @Route(value = "sendComment", method = HttpMethod.POST)
    @JSON
    public RestResponse sendComment(Request request, Response response) {


        Map<String, String> querys = request.querys();
        String text = querys.get("text");
        String author = querys.get("author");
        String mail = querys.get("mail");
        if (author.length() > 50) {
            return RestResponse.fail("姓名过长");
        }

        if (text.length() > 200) {
            return RestResponse.fail("请输入200个字符以内的评论");
        }


        author = BlogUtils.cleanXSS(author);
        text = BlogUtils.cleanXSS(text);

        author = EmojiParser.parseToAliases(author);
        text = EmojiParser.parseToAliases(text);

        Comments comments = new Comments();
        comments.setAuthor(author);
        comments.setCid(1);
        comments.setIp(request.address());
        comments.setUrl("");
        comments.setContent(text);
        comments.setMail(mail);
        comments.setParent(0);
        try {
            commentsService.saveComment(comments);
            return RestResponse.ok();
        } catch (Exception e) {
            String msg = "评论发布失败";
            if (e instanceof TipException) {
                msg = e.getMessage();
            } else {
                LOGGER.error(msg, e);
            }
            return RestResponse.fail(msg);
        }
    }


}
