package com.javablog.controller.admin;

import com.blade.ioc.annotation.Inject;
import com.blade.kit.DateKit;
import com.blade.kit.StringKit;
import com.blade.kit.json.JSONKit;
import com.blade.mvc.annotation.Controller;
import com.blade.mvc.annotation.JSON;
import com.blade.mvc.annotation.QueryParam;
import com.blade.mvc.annotation.Route;
import com.blade.mvc.http.HttpMethod;
import com.blade.mvc.http.Request;
import com.blade.mvc.http.Response;
import com.blade.mvc.http.wrapper.Session;
import com.blade.mvc.view.RestResponse;
import com.javablog.controller.BaseController;
import com.javablog.dto.LogActions;
import com.javablog.exception.TipException;
import com.javablog.init.BlogConst;
import com.javablog.model.Users;
import com.javablog.service.LogService;
import com.javablog.service.UsersService;
import com.javablog.utils.BlogUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller("admin")
public class AuthController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthController.class);

    @Inject
    private UsersService usersService;

    @Inject
    private LogService logService;

    @Route(value = "login", method = HttpMethod.GET)
    public String login(Response response) {
        if(null != this.user()){
            response.go("/admin/index");
            return null;
        }
        return "admin/login";
    }

    @Route(value = "login", method = HttpMethod.POST)
    @JSON
    public RestResponse doLogin(@QueryParam String username,
                                @QueryParam String password,
                                @QueryParam String remeber_me,
                                Request request,
                                Session session, Response response) {

        Integer error_count = cache.get("login_error_count");
        try {
            error_count = null == error_count ? 0 : error_count;

            if(null != error_count && error_count > 3){
                return RestResponse.fail("您输入密码已经错误超过3次，请10分钟后尝试");
            }

            Users user = usersService.login(username, password);
            session.attribute(BlogConst.LOGIN_SESSION_KEY, user);
            if (StringKit.isNotBlank(remeber_me)) {
                BlogUtils.setCookie(response, user.getUid());
            }
            Users temp = new Users();
            temp.setUid(user.getUid());
            temp.setLogged(DateKit.getCurrentUnixTime());
            usersService.update(temp);
            LOGGER.info("登录成功：{}", JSONKit.toJSONString(request.querys()));
            cache.set("login_error_count", 0);
            logService.save(LogActions.LOGIN, JSONKit.toJSONString(request.querys()), request.address(), user.getUid());
        } catch (Exception e) {
            error_count+=1;
            cache.set("login_error_count", error_count, 10 * 60);
            String msg = "登录失败";
            if (e instanceof TipException) {
                msg = e.getMessage();
            } else {
                LOGGER.error(msg, e);
            }
            return RestResponse.fail(msg);
        }
        return RestResponse.ok();
    }

}
