package com.javablog.service.impl;

import com.blade.ioc.annotation.Inject;
import com.blade.ioc.annotation.Service;
import com.blade.jdbc.ActiveRecord;
import com.blade.jdbc.core.Take;
import com.blade.jdbc.model.Paginator;
import com.blade.kit.DateKit;
import com.javablog.init.BlogConst;
import com.javablog.model.Logs;
import com.javablog.service.LogService;

import java.util.List;

@Service
public class LogServiceImpl implements LogService {

    @Inject
    private ActiveRecord activeRecord;

    @Override
    public void save(String action, String data, String ip, Integer author_id) {
        Logs logs = new Logs();
        logs.setAction(action);
        logs.setData(data);
        logs.setIp(ip);
        logs.setAuthor_id(author_id);
        logs.setCreated(DateKit.getCurrentUnixTime());
        activeRecord.insert(logs);
    }

    @Override
    public List<Logs> getLogs(int page, int limit) {
        if (page <= 0) {
            page = 1;
        }

        if (limit < 1 || limit > BlogConst.MAX_POSTS) {
            limit = 10;
        }
        Paginator<Logs> logsPaginator = activeRecord.page(new Take(Logs.class).page(page, limit, "id desc"));
        return logsPaginator.getList();
    }
}
